<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class image_category extends Model
{
    //
}
