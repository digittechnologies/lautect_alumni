<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class app_category extends Model
{
    //
}
