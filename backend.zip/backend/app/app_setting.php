<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class app_setting extends Model
{
    //
}
