<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class event_schedule extends Model
{
    //
}
