<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class people_commitee extends Model
{
    //
}
