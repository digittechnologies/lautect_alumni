<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class career_category extends Model
{
    //
}
