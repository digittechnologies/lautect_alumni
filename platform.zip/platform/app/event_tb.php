<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class event_tb extends Model
{
    //
}
